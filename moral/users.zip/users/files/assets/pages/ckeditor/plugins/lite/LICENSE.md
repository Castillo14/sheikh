Software License Agreement
==========================

Copyright (c) 2016 Loopindex.com, (David *)Frenkiel
The ICE system Copyright (c) The New York Times, CMS Group, Matthew 
DeLambo, see the LICENSE file in the ice folder.

<h4>GPL 2.0</h4>

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License, version 2, as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program as the file gpl.txt. If not, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt


